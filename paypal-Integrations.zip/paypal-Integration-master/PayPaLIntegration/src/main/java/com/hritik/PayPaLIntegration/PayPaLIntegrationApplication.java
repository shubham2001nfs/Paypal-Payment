package com.hritik.PayPaLIntegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayPaLIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayPaLIntegrationApplication.class, args);
	}

}
